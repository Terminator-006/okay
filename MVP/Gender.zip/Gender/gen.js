document.addEventListener('DOMContentLoaded', function() {
    const nextButton = document.getElementById('next-button');
    const nextButtonSlider1 = document.getElementById('next-button-slider1');
    const prevButtonSlider2 = document.getElementById('prev-button-slider2');
    const carousel = document.querySelector('.carousel');
  
    let currentSlide = 0;
  
    function goToNextSlide() {
      currentSlide = (currentSlide + 1) % 2;
      updateCarousel();
    }
  
    function goToPreviousSlide() {
      currentSlide = (currentSlide - 1 + 2) % 2;
      updateCarousel();
    }
  
    function updateCarousel() {
      if (currentSlide === 1) {
        carousel.style.transform = 'translateX(-50%)'; // Move to the second slide
        nextButton.disabled = false; // Enable the "Next" button
        nextButton.style.opacity = '1'; // Fully opaque
        nextButton.style.cursor = 'pointer'; // Change cursor to pointer
      } else {
        carousel.style.transform = 'translateX(0)'; // Move to the first slide
      }
    }
  
    nextButton.addEventListener('click', goToNextSlide);
    nextButtonSlider1.addEventListener('click', goToNextSlide);
    prevButtonSlider2.addEventListener('click', goToPreviousSlide);
  });
  